import{r as React,j as jsx,m as motion,c as cn}from"./main-BWk4fnlg.js";

const gradients={
  scraaatch:"linear-gradient(135deg, #f5cf67 0%, #e1a316 48%, #cb7f00 100%)",
  anass:"linear-gradient(135deg, #d69af8 0%, #9646dd 50%, #6417b5 100%)",
  "daily-story":"linear-gradient(135deg, #91cca3 0%, #4f9b68 50%, #2f6e49 100%)",
  "zod-json-schema-builder":"linear-gradient(135deg, #8ab8ff 0%, #4684eb 50%, #2558be 100%)",
  "melany-portfolio":"linear-gradient(135deg, #6b6b76 0%, #2f2f37 38%, #111116 72%, #4b4b58 100%)"
};

const InteractiveCard=({children,containerClassName,className,containerStyle})=>{
  const[mouse,setMouse]=React.useState({x:0,y:0});
  const[hovered,setHovered]=React.useState(false);
  const handleMouseMove=(event)=>{
    const{clientX,clientY}=event;
    const rect=event.currentTarget.getBoundingClientRect();
    const x=(clientX-(rect.left+rect.width/2))/20;
    const y=(clientY-(rect.top+rect.height/2))/20;
    setMouse({x,y});
  };

  return jsx.jsx(motion.section,{
    onMouseMove:handleMouseMove,
    onMouseEnter:()=>setHovered(true),
    onMouseLeave:()=>{
      setHovered(false);
      setMouse({x:0,y:0});
    },
    style:{
      ...containerStyle,
      transform:hovered?`translate3d(${mouse.x}px, ${mouse.y}px, 0) scale3d(1, 1, 1)`:"translate3d(0px, 0px, 0) scale3d(1, 1, 1)",
      transition:"transform 0.1s ease-out"
    },
    className:cn("mx-auto w-full bg-primary relative rounded-2xl overflow-hidden",containerClassName),
    children:jsx.jsx("div",{
      className:"relative h-full [background-image:radial-gradient(88%_100%_at_top,rgba(255,255,255,0.5),rgba(255,255,255,0))] sm:mx-0 sm:rounded-2xl overflow-hidden",
      style:{
        boxShadow:"0 10px 32px rgba(34, 42, 53, 0.12), 0 1px 1px rgba(0, 0, 0, 0.05), 0 0 0 1px rgba(34, 42, 53, 0.05), 0 4px 6px rgba(34, 42, 53, 0.08), 0 24px 108px rgba(47, 48, 55, 0.10)"
      },
      children:jsx.jsxs(motion.div,{
        style:{
          transform:hovered?`translate3d(${-mouse.x}px, ${-mouse.y}px, 0) scale3d(1.03, 1.03, 1)`:"translate3d(0px, 0px, 0) scale3d(1, 1, 1)",
          transition:"transform 0.1s ease-out"
        },
        className:cn("h-full px-4 py-20 sm:px-10",className),
        children:[jsx.jsx(NoiseOverlay,{}),children]
      })
    })
  });
};

const NoiseOverlay=()=>jsx.jsx("div",{
  className:"absolute inset-0 w-full h-full scale-[1.2] transform opacity-10 [mask-image:radial-gradient(#fff,transparent,75%)] z-0",
  style:{backgroundImage:"url(/noise.webp)",backgroundSize:"30%"}
});

const ProjectCard=({project,withImagePadding=false})=>jsx.jsx(InteractiveCard,{
  className:"flex-col sm:flex-row h-full !pt-2 pb-4 !px-4 sm:!px-6 flex rounded-2xl relative mx-auto group overflow-hidden",
  containerClassName:cn(project.styles.bgColor,project.styles.textColor),
  containerStyle:project.styles.background?{background:project.styles.background||gradients[project.id]}:{background:gradients[project.id]},
  children:jsx.jsxs("div",{
    className:"flex flex-row items-start gap-4 p-0",
    children:[
      jsx.jsx("div",{
        className:cn("self-start flex-shrink-0",{"pt-2":withImagePadding}),
        children:jsx.jsx("img",{
          src:project.thumbnail,
          alt:project.title,
          className:cn("size-28 md:size-30 block object-contain rounded-[1.6rem]",project.id==="melany-portfolio"&&"scale-[0.82]")
        })
      }),
      jsx.jsx("div",{
        className:"flex flex-col justify-between items-start gap-2 z-20 text-left max-w-[300px] sm:max-w-[340px] md:max-w-[380px] break-words min-w-0",
        children:jsx.jsxs("div",{
          className:"flex flex-col gap-1",
          children:[
            jsx.jsx("h2",{className:"text-2xl md:text-3xl !mb-0 font-bold tracking-tight line-clamp-2 !text-inherit group-hover:scale-[1.02] transition-transform duration-200 ",children:project.title}),
            jsx.jsx("span",{className:"text-xs md:text-base line-clamp-4 hyphens-auto",children:project.description})
          ]
        })
      })
    ]
  })
});

export{ProjectCard as P,InteractiveCard as W};
