import{g,r as d}from"./main-BWk4fnlg.js";const y=r=>typeof r=="boolean"?`${r}`:r===0?"0":r,w=g,$=(r,t)=>e=>{var a;if(t?.variants==null)return w(r,e?.class,e?.className);const{variants:l,defaultVariants:n}=t,v=Object.keys(l).map(o=>{const s=e?.[o],c=n?.[o];if(s===null)return null;const i=y(s)||y(c);return l[o][i]}),u=e&&Object.entries(e).reduce((o,s)=>{let[c,i]=s;return i===void 0||(o[c]=i),o},{}),m=t==null||(a=t.compoundVariants)===null||a===void 0?void 0:a.reduce((o,s)=>{let{class:c,className:i,...b}=s;return Object.entries(b).every(k=>{let[f,C]=k;return Array.isArray(C)?C.includes({...n,...u}[f]):{...n,...u}[f]===C})?[...o,c,i]:o},[]);return w(r,v,m,e?.class,e?.className)};/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),N=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(t,e,a)=>a?a.toUpperCase():e.toLowerCase()),h=r=>{const t=N(r);return t.charAt(0).toUpperCase()+t.slice(1)},A=(...r)=>r.filter((t,e,a)=>!!t&&t.trim()!==""&&a.indexOf(t)===e).join(" ").trim(),V=r=>{for(const t in r)if(t.startsWith("aria-")||t==="role"||t==="title")return!0};/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var j={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=d.forwardRef(({color:r="currentColor",size:t=24,strokeWidth:e=2,absoluteStrokeWidth:a,className:l="",children:n,iconNode:v,...u},m)=>d.createElement("svg",{ref:m,...j,width:t,height:t,stroke:r,strokeWidth:a?Number(e)*24/Number(t):e,className:A("lucide",l),...!n&&!V(u)&&{"aria-hidden":"true"},...u},[...v.map(([o,s])=>d.createElement(o,s)),...Array.isArray(n)?n:[n]]));/**
 * @license lucide-react v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=(r,t)=>{const e=d.forwardRef(({className:a,...l},n)=>d.createElement(L,{ref:n,iconNode:t,className:A(`lucide-${x(h(r))}`,`lucide-${r}`,a),...l}));return e.displayName=h(r),e};export{$ as a,E as c};
