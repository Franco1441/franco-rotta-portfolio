import{b as r}from"./_baseUniq-o4zM8p8H.js";var e=4;function a(o){return r(o,e)}export{a as c};
