import{j as e}from"./main-BWk4fnlg.js";import{I as r}from"./chunk-SNIEDJZS-0ROJD6Oa.js";import{H as a}from"./highlighter-BiT7-Plp.js";function t(i){const n={h2:"h2",li:"li",p:"p",ul:"ul",...i.components};return e.jsxs(e.Fragment,{children:[e.jsx(r,{src:"/bitmoji.webp",alt:"Franco Rotta illustration",width:220,height:220}),`
`,e.jsx(n.h2,{children:"Full Stack Developer | 2024 - Present"}),`
`,e.jsxs(n.ul,{children:[`
`,e.jsxs(n.li,{children:[`
`,e.jsxs(n.p,{children:["Integrated Google Gemini into the platform and built the first AI Agent that increased the company's loan book while helping customers achieve their goals faster. It also received an ",e.jsx(a,{action:"underline",color:"var(--color-amber-600)",children:" award! "})," 🥇"]}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Built a Next.js commerce flow for Tostadero Wellington with Mercado Pago checkout and server-side webhooks into Supabase."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Built an internal operations board, cart persistence and discount logic for day-to-day order management."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Designed and implemented SEMO's WhatsApp appointment flow with Twilio, Node.js and Express."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Developed a React/Vite admin panel with role-based access and PostgreSQL scheduling logic for six specialties."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Delivered Sancor's React + Vite + Tailwind quote flow with Netlify Functions and real-time validation."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Shipped and maintained these tools through deployment, operations and iterative client feedback."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Worked end-to-end from product requirements to launch, keeping a strong focus on reliability and user flow."}),`
`]}),`
`]}),`
`,e.jsx(r,{src:"/bitmoji.webp",alt:"Franco Rotta illustration",width:220,height:220,loading:"lazy"}),`
`,e.jsx(n.h2,{children:"Audiovisual Production & Streaming | 2021 - Present"}),`
`,e.jsxs(n.ul,{children:[`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Project-based and ongoing production work across Insert BIC / Insert Beat and Iglesia Brazos Abiertos."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Planned and executed 4K multicam productions (S-Log3) with 3 to 5 cameras and occasional live switching with ATEM Mini Pro."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Led hired camera operators and owned pre-production, technical direction, post-production and delivery."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Delivered publish-ready edits under tight turnaround requirements, often in under 24 hours."}),`
`]}),`
`,e.jsxs(n.li,{children:[`
`,e.jsx(n.p,{children:"Produced 10+ event productions and 50+ edited assets across social, event and streaming cycles."}),`
`]}),`
`]})]})}function o(i={}){const{wrapper:n}=i.components||{};return n?e.jsx(n,{...i,children:e.jsx(t,{...i})}):t(i)}function d(){return e.jsx("main",{className:"max-h-fit px-4 md:px-8 lg:px-12 flex-1",children:e.jsx(o,{})})}export{d as component};
